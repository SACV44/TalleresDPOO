package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import uniandes.dpoo.hamburguesas.excepciones.IngredienteRepetidoException;
import uniandes.dpoo.hamburguesas.excepciones.NoHayPedidoEnCursoException;
import uniandes.dpoo.hamburguesas.excepciones.ProductoFaltanteException;
import uniandes.dpoo.hamburguesas.excepciones.ProductoRepetidoException;
import uniandes.dpoo.hamburguesas.excepciones.YaHayUnPedidoEnCursoException;
import uniandes.dpoo.hamburguesas.mundo.Restaurante;

class RestauranteTest {
	
	
	Restaurante re;
	

	
	
	
	
	@Test
    public void testIniciarPedido() throws Exception {
        Restaurante r = new Restaurante();
        r.iniciarPedido("Ari", "cra 999");

        assertThrows(YaHayUnPedidoEnCursoException.class, () ->
            r.iniciarPedido("Otro", "otra dir"));

        assertEquals("Ari", r.getPedidoEnCurso().getNombreCliente());
    }
    
	@Test
    public void cerrarYGuardarPedido() throws Exception {
    	
    	Restaurante r = new Restaurante();
    	
    	r.iniciarPedido("chlindrina", "vecindad");
    	new File("./facturas").mkdirs();
 		r.cerrarYGuardarPedido();
    	
    	assertThrows(NoHayPedidoEnCursoException.class, () -> 
    			r.cerrarYGuardarPedido());
    	
    	
    	
    }
	
	
	
	@Test
	public void testGetPedidoEnCurso() throws YaHayUnPedidoEnCursoException, NoHayPedidoEnCursoException, IOException {
		
		
		Restaurante re = new Restaurante();
		

		re.iniciarPedido("chlindrina", "vecindad");
		
		
	
		assertEquals("chlindrina", re.getPedidoEnCurso().getNombreCliente());
	 }
    
	 
	@Test
	public void testGetPedidos() throws YaHayUnPedidoEnCursoException, NoHayPedidoEnCursoException, IOException {
		
		Restaurante re = new Restaurante();
		
		re.iniciarPedido("la popis", "vecindad");
	    new File("./facturas").mkdirs();
		re.cerrarYGuardarPedido();
		
		
	
	    assertEquals(1, re.getPedidos().size());
	    }
	 
	 
	@TempDir
	Path tempDir;
	 
	@Test
	public void testCargarIngredientesMenuCombos() throws Exception {
		
		Restaurante r = new Restaurante();
		
		Path ing = tempDir.resolve("ingredientes.txt");
        Path menu = tempDir.resolve("menu.txt");
        Path combos = tempDir.resolve("combos.txt");
        
        Files.writeString(ing, "Lechuga;1000\nSala;2000\n");
        Files.writeString(menu, "Papas;1200\nHelado;200\n");   
        Files.writeString(combos, "SoloPapas;10%;Papas\n" +"Duo;25%;Papas;Helado\n");  
        
        
        r.cargarInformacionRestaurante(ing.toFile(), menu.toFile(), combos.toFile());
        
        assertEquals(2, r.getIngredientes().size());
        assertEquals("Lechuga", r.getIngredientes().get(0).getNombre());
        assertEquals("Sala", r.getIngredientes().get(1).getNombre());
        assertEquals(1000, r.getIngredientes().get(0).getCostoAdicional());
        assertEquals(2000, r.getIngredientes().get(1).getCostoAdicional());
        
        assertEquals(2, r.getMenuBase().size());
        assertEquals("Papas",  r.getMenuBase().get(0).getNombre());
        assertEquals("Helado", r.getMenuBase().get(1).getNombre());
        assertEquals(1200, r.getMenuBase().get(0).getPrecio());
        assertEquals(200,  r.getMenuBase().get(1).getPrecio());
        
        assertEquals(2, r.getMenuCombos().size());
        assertEquals("SoloPapas", r.getMenuCombos().get(0).getNombre());
        assertEquals(1080,       r.getMenuCombos().get(0).getPrecio());
        assertEquals("Duo",      r.getMenuCombos().get(1).getNombre());
        assertEquals(1050,       r.getMenuCombos().get(1).getPrecio());
        
		 
	 }
	
	
	@Test
	
	 public void testCargarIngredientes2() throws Exception {
		
		Restaurante r = new Restaurante();
		
		Path ing = tempDir.resolve("ingredientes.txt");
	    Path menu = tempDir.resolve("menu.txt");
	    Path combos = tempDir.resolve("combos.txt");
		
	    Files.writeString(ing, "Queso;1000\nQueso;1500\n");
	    Files.writeString(menu, "");
	    Files.writeString(combos, "");

	    assertThrows(IngredienteRepetidoException.class, () -> 
	           r.cargarInformacionRestaurante(ing.toFile(), menu.toFile(), combos.toFile()));
	        
		
	}
	
	@Test
	public void cargarMenu2() throws Exception {
		
		Restaurante r = new Restaurante();
		
		Path ing = tempDir.resolve("ingredientes.txt");
        Path menu = tempDir.resolve("menu.txt");
        Path combos = tempDir.resolve("combos.txt");
        
        Files.writeString(ing, "");
        Files.writeString(menu, "Popis;1000\nPopis;1500\n");   
        Files.writeString(combos, ""); 
	 
        assertThrows(ProductoRepetidoException.class, () -> 
        	r.cargarInformacionRestaurante(ing.toFile(), menu.toFile(), combos.toFile()));	
        
    
	}
	
	
	@Test
	public void cargarCombos2() throws Exception {
	   
		Restaurante r = new Restaurante();

	    Path ing = tempDir.resolve("ingredientes.txt");
	    Path menu = tempDir.resolve("menu.txt");
	    Path combos = tempDir.resolve("combos.txt");

	    Files.writeString(ing, "");
	    Files.writeString(menu, "Papas;1200\n");                   
	    Files.writeString(combos, "Duo;10%;Papas\nDuo;15%;Papas\n"); 

	    assertThrows(ProductoRepetidoException.class, () ->
	        r.cargarInformacionRestaurante(ing.toFile(), menu.toFile(), combos.toFile()));
	}   
	
	@Test
	public void cargarCombos_productoFaltante_lanza() throws Exception {
	    Restaurante r = new Restaurante();

	    Path ing = tempDir.resolve("ingredientes.txt");
	    Path menu = tempDir.resolve("menu.txt");
	    Path combos = tempDir.resolve("combos.txt");

	    Files.writeString(ing, "");
	    Files.writeString(menu, "Papas;1200\n");                      
	    Files.writeString(combos, "ComboRaro;10%;Papas;Refresco\n");  

	    assertThrows(ProductoFaltanteException.class, () ->
	        r.cargarInformacionRestaurante(ing.toFile(), menu.toFile(), combos.toFile()));
	    
	}
	
	
	
	
	
	
}


