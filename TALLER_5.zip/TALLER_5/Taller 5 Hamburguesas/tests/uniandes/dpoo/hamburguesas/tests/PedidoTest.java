package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.Pedido;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

class PedidoTest {

	
	Pedido pedido;
	
	@BeforeEach
	
	
	public void setUp() {
		
		
		pedido = new Pedido("Ari", "cra 999");
		
		
			
	}
	
	@Test
	
	public void testGetIdPedido() {
		
	    Pedido p1 = new Pedido("A", "X");
	    Pedido p2 = new Pedido("B", "Y");

	    assertEquals(p1.getIdPedido() + 1, p2.getIdPedido());
	}
	
	
	@Test
	public void testGetNombreCliente() {
		
		assertEquals("Ari", pedido.getNombreCliente());
		
	}
	
	
	@Test
	
	public void testAgregarProducto() {
		
		
		ProductoMenu producto1 = new ProductoMenu("Hamburguesa", 10000);
		
		pedido.agregarProducto(producto1);
		
	    double totalEsperado = (int) (10000 + (10000*0.19));

	    
	    assertEquals(totalEsperado, pedido.getPrecioTotalPedido());

		
	}
	
	
	  @Test
	  public void testPrecioNetoPedido() {
		  
		  pedido.agregarProducto(new ProductoMenu("A", 7000));
	      pedido.agregarProducto(new ProductoMenu("B", 3000));
	      
	      Integer netoEsperado = 7000 + 3000; 
	      
	      String netoEsperado1 = Integer.toString(netoEsperado);
	      
	      String factura = pedido.generarTextoFactura();
	        
	      assertTrue(factura.contains(netoEsperado1));


		  
	  }
	  
	  @Test
	  public void testPrecioIVAPedido() {
		  
	        pedido.agregarProducto(new ProductoMenu("P50", 50));
	        pedido.agregarProducto(new ProductoMenu("P51", 51));
	        
	        int ivaEsperado = (int) ((50 + 51) * 0.19);
	        
	        String ivaEsperado1 = Integer.toString(ivaEsperado);
	        
	        String factura = pedido.generarTextoFactura();
	        assertTrue(factura.contains(ivaEsperado1));
		  
		  
	  }
	  
	  
	  @Test
	    public void testGenerarTextoFactura() {
		
		  pedido.agregarProducto(new ProductoMenu("Hamburguesa", 10000));
	      pedido.agregarProducto(new ProductoMenu("Papas", 3000));
	      
	      int ivaEsperado  = (int) ((13000) * 0.19); //2470
	      int totalEsperado = 13000 + ivaEsperado; // 15470

	      String factura = pedido.generarTextoFactura();
	      
	      
	      assertTrue(factura.contains("Ari"));
	      assertTrue(factura.contains("cra 999"));
	      
	      
	        assertTrue(factura.contains("Hamburguesa"));
	        assertTrue(factura.contains("10000"));
	        assertTrue(factura.contains("Papas"));
	        assertTrue(factura.contains("3000"));
	        
	        assertTrue(factura.contains("13000"));
	        assertTrue(factura.contains("2470"));
	        assertTrue(factura.contains("15470"));

		  
		  
	  	}
	  
	  
	  
	  @Test
	  public void testGuardarFactura() throws Exception {
		  
		 pedido.agregarProducto(new ProductoMenu("Hamburguesa", 10000));
		 
	     Path temp = Files.createTempFile("factura-", ".txt");  
	     File destino = temp.toFile();
		 
	     
	        pedido.guardarFactura(destino);

	        String contenido = Files.readString(temp);
	        assertTrue(contenido.contains("Ari"));
	        assertTrue(contenido.contains("Hamburguesa"));
	        assertTrue(contenido.contains("10000"));
		  
	  	}
	  
	  }
	  
	  
	

