package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

class ProductoMenuTest {

    private ProductoMenu producto;

	
	@BeforeEach
	
	public void setUp() {
		
		producto = new ProductoMenu("Hamburguesa", 10000);	
	}
	
	
	@Test
    public void testGetNombre() {
        assertEquals("Hamburguesa", producto.getNombre());
    }

	
	@Test
	public void testGetPrecio() {
		
		assertEquals(10000, producto.getPrecio());
		
	}
	
	@Test
	public void testGenerarTextoFactura() {
		
		
		String factura = producto.generarTextoFactura();
		
		
		assertTrue(factura.contains(producto.getNombre()));
		assertTrue(factura.contains("10000"));
	}
}
