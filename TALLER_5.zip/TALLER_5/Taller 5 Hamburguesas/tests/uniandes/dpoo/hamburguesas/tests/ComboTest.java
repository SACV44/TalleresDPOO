package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.Combo;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

class ComboTest {
	
	
	ProductoMenu productoBase1;
	ProductoMenu productoBase2;
	ProductoMenu productoBase3;
	
	Combo combo;
	
	@BeforeEach
	
	public void setUp() { 	
		
		productoBase1 = new ProductoMenu("Hamburguesa", 50);
		productoBase2 = new ProductoMenu("Limonada", 40);
		productoBase3 = new ProductoMenu("Papas", 10);

		ArrayList<ProductoMenu> lista = new ArrayList<ProductoMenu>();
		
		lista.add(productoBase1);
		lista.add(productoBase2);
		lista.add(productoBase3);
		
		
		combo = new Combo("macdo", 0.1, lista);
		
		
	}
	

	@Test
	public void testGetNombre() {
		
		assertEquals("macdo", combo.getNombre());
		
	}
	
	@Test
	public void testGetPrecio() {
		
		assertEquals(90, combo.getPrecio());
		
	}
	
	
	
	
	@Test
	public void testGenerarTextoFactura() {
		
		String texto = combo.generarTextoFactura();
		
		assertTrue(texto.contains("macdo"));
		assertTrue(texto.contains("0.1"));
		assertTrue(texto.contains("90"));
		
		
		
		
	}
}
