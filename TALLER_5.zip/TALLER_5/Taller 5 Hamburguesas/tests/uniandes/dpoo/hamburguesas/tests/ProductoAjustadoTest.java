package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.Ingrediente;
import uniandes.dpoo.hamburguesas.mundo.ProductoAjustado;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

class ProductoAjustadoTest {

	private ProductoMenu productoBase;
	private ProductoAjustado productoAjustado;
	
	private Ingrediente ingrediente1;
	private Ingrediente ingrediente2;
	private Ingrediente ingrediente3;
	private Ingrediente ingrediente4;
	
	@BeforeEach
	
	public void setUp() {
		
		productoBase = new ProductoMenu("Hamburguesa", 10000);
		productoAjustado = new ProductoAjustado(productoBase);
		
		ingrediente1 = new Ingrediente("Papa", 10);
		ingrediente2 = new Ingrediente("Aloe", 10);
		
		
		ingrediente3 = new Ingrediente("Caca", 10);
		ingrediente4 = new Ingrediente("Cilantro", 10);
		
		productoAjustado.agregarIngrediente(ingrediente1);
		productoAjustado.agregarIngrediente(ingrediente2);

		
		
		productoAjustado.quitarIngrediente(ingrediente3);
		productoAjustado.quitarIngrediente(ingrediente4);
		
	}
	
	
	
	@Test
	@DisplayName("Nombre")
	public void testGetNombre() {
		
			assertEquals(productoAjustado.getNombre(), "Hamburguesa");	
			
		
	}
	
	@Test
	public void testGetPrecio() {
		
		assertEquals(productoAjustado.getPrecio(), 10020);
		
		
	}
	
	@Test
	public void testEliminado() {
		
		assertTrue(productoAjustado.getEliminados().contains(ingrediente3));
		assertTrue(productoAjustado.getEliminados().contains(ingrediente4));
		
	}
	
	
	@Test
	public void testAnadidos() {
		
		assertTrue(productoAjustado.getAgregados().contains(ingrediente1));
		assertTrue(productoAjustado.getAgregados().contains(ingrediente2));

		
	}
	
	@Test
	public void testGenerarTextoFactura() {
		
		String factura = productoAjustado.generarTextoFactura();
		
		assertTrue(factura.contains(productoBase.getNombre()));	
		assertTrue(factura.contains("Papa"));
		assertTrue(factura.contains("Caca"));
		assertTrue(factura.contains("Aloe"));
		assertTrue(factura.contains("Cilantro"));
		
		
	}
	
	
	
	

}
