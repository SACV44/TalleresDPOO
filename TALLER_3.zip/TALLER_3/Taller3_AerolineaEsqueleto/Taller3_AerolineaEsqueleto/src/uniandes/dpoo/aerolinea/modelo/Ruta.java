package uniandes.dpoo.aerolinea.modelo;

/**
 * Esta clase tiene la información de una ruta entre dos aeropuertos que cubre una aerolínea.
 */
public class Ruta
{
    private String horaSalida;
    private String horaLlegada;
    private String codigoRuta;
    
    private Aeropuerto origen;
    private Aeropuerto destino;
    
    
    public Ruta(Aeropuerto origen, Aeropuerto destino, String horaSalida, String horaLlegada, String codigoRuta) {
    	
    	this.horaSalida = horaSalida;
    	this.horaLlegada = horaLlegada;
    	this.codigoRuta = codigoRuta;
    	this.destino = destino;
    	this.origen = origen;
    }
    
    
    public String getHoraSalida() {
		return horaSalida;
	}


	public String getHoraLlegada() {
		return horaLlegada;
	}


	public String getCodigoRuta() {
		return codigoRuta;
	}


	public Aeropuerto getOrigen() {
		return origen;
	}


	public Aeropuerto getDestino() {
		return destino;
	}


	public int getDuracion() {
		
		int dep_minutes = Integer.parseInt(horaSalida) % 100;
		int dep_hours = Integer.parseInt(horaSalida) / 100;
		
		int arr_minutes = Integer.parseInt(horaLlegada) % 100;
		int arr_hours = Integer.parseInt(horaLlegada) / 100;
		
		
		
		
		dep_minutes = (dep_hours * 60) + dep_minutes;
		arr_minutes = (arr_hours * 60) + arr_minutes;
	
		int distance = arr_minutes - dep_minutes;
		
		if (distance < 0) {
			
			distance = (24*60 - dep_minutes + arr_minutes);
		}
		
		
		// QUÉ SE HACE SI ES DE UN DÍA PARA OTRO
		
		return distance;
		
	}


	/**
     * Dada una cadena con una hora y minutos, retorna los minutos.
     * 
     * Por ejemplo, para la cadena '715' retorna 15.
     * @param horaCompleta Una cadena con una hora, donde los minutos siempre ocupan los dos últimos caracteres
     * @return Una cantidad de minutos entre 0 y 59
     */
    public static int getMinutos( String horaCompleta )
    {
        int minutos = Integer.parseInt( horaCompleta ) % 100;
        return minutos;
    }

    /**
     * Dada una cadena con una hora y minutos, retorna las horas.
     * 
     * Por ejemplo, para la cadena '715' retorna 7.
     * @param horaCompleta Una cadena con una hora, donde los minutos siempre ocupan los dos últimos caracteres
     * @return Una cantidad de horas entre 0 y 23
     */
    public static int getHoras( String horaCompleta )
    {
        int horas = Integer.parseInt( horaCompleta ) / 100;
        return horas;
    }

    
}
