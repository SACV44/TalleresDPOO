package uniandes.dpoo.aerolinea.modelo.tarifas;

import uniandes.dpoo.aerolinea.modelo.Aeropuerto;
import uniandes.dpoo.aerolinea.modelo.Ruta;
import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;

public abstract class CalculadoraTarifas {
	
	public double IMPUESTO = 0.28;
	
	
	public int calcularTarifa(Vuelo vuelo, Cliente cliente) {
		
		double costobase = calcularCostoBase(vuelo, cliente);
		double descuento = calcularPorcentajeDescuento(cliente);
		
		
		return (int) (((1-descuento)*costobase )* (1+IMPUESTO));
		
		
		
	}
	
	
	protected abstract int calcularCostoBase(Vuelo vuelo, Cliente cliente);

	protected abstract double calcularPorcentajeDescuento(Cliente client);
	
	protected int calcularDistanciaVuelo(Ruta ruta) {
		
		Aeropuerto origen = ruta.getOrigen();
		Aeropuerto destino = ruta.getDestino();
		
		int distancia = Aeropuerto.calcularDistancia(origen, destino);
		
		return distancia;
	}
	
	protected int calcularValorImpuestos(int costoBase) {
		
		Integer recaudo = (int) (costoBase * IMPUESTO);
		
		int rec = recaudo;
		
		return rec;
	}
	
	
}
