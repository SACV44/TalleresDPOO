package uniandes.dpoo.aerolinea.consola;

import java.io.IOException;

import uniandes.dpoo.aerolinea.exceptions.AeropuertoDuplicadoException;
import uniandes.dpoo.aerolinea.exceptions.InformacionInconsistenteException;
import uniandes.dpoo.aerolinea.modelo.Aerolinea;
import uniandes.dpoo.aerolinea.persistencia.CentralPersistencia;
import uniandes.dpoo.aerolinea.persistencia.TipoInvalidoException;
import uniandes.dpoo.aerolinea.modelo.Ruta;
import uniandes.dpoo.aerolinea.modelo.Aeropuerto;

public class ConsolaArerolinea extends ConsolaBasica
{
    private Aerolinea unaAerolinea;

    /**
     * Es un método que corre la aplicación y realmente no hace nada interesante: sólo muestra cómo se podría utilizar la clase Aerolínea para hacer pruebas.
     */
    public void correrAplicacion( )
    {
        try
        {
            unaAerolinea = new Aerolinea( );
            // String archivo = this.pedirCadenaAlUsuario( "Digite el nombre del archivo json con la información de una aerolinea" );
            String archivo = "tiquetes.json"; 
            unaAerolinea.cargarTiquetes( "./datos/" + archivo, CentralPersistencia.JSON );
        }
        catch( TipoInvalidoException e )
        {
            e.printStackTrace( );
        }
        catch( IOException e )
        {
            e.printStackTrace();
        }
        catch( InformacionInconsistenteException e )
        {
            e.printStackTrace();
        }
    }

    public static void main( String[] args ) throws AeropuertoDuplicadoException
    {
        ConsolaArerolinea ca = new ConsolaArerolinea( );
        //ca.correrAplicacion( );
        
        // PRUEBAS
        
    
        Aeropuerto bog = new Aeropuerto("El Dorado", "BOG", "Bogotá", 4.70159, -74.1469);
        Aeropuerto jfk = new Aeropuerto("John F. Kennedy", "JFK", "New York", 40.6413, -73.7781);
        
        
		Ruta rutaBogJfk = new Ruta(bog, jfk, "1030", "1130", "324");
		
		int A = rutaBogJfk.getDuracion();
		
		System.out.println(A);
        
        
    }
}
