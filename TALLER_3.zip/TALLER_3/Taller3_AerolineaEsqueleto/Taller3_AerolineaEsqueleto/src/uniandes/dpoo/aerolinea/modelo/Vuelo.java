package uniandes.dpoo.aerolinea.modelo;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import uniandes.dpoo.aerolinea.exceptions.VueloSobrevendidoException;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;
import uniandes.dpoo.aerolinea.modelo.tarifas.CalculadoraTarifas;
import uniandes.dpoo.aerolinea.tiquetes.GeneradorTiquetes;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public class Vuelo {

	private Avion avion;
	private String fecha; //YYYY-MM-DD
	private Ruta ruta;
	private Map<String, Tiquete> tiquetes;
	
	
	
	public Vuelo(Ruta ruta, String fecha, Avion avion){
		
		this.ruta = ruta;
		this.fecha = fecha;
		this.avion = avion;
		this.tiquetes = new HashMap<>();
		
	}
	
	
	public Avion getAvion() {
		return avion;
	}


	public String getFecha() {
		return fecha;
	}


	public Ruta getRuta() {
		return this.ruta;
	}

	

	public Map<String, Tiquete> getTiquetes() {
		return tiquetes;
	}
	
	public int venderTiquetes(Cliente cliente, CalculadoraTarifas calculadora, int cantidad) throws VueloSobrevendidoException 
	{
		
		int tarifa = calculadora.calcularTarifa(this, cliente);
		
		
		for(int i=0; i<cantidad;i++) {
			
			
			
			Tiquete tiket = GeneradorTiquetes.generarTiquete(this, cliente, tarifa);
			
			if (avion.getCapacidad() > tiquetes.size()) {
				
				tiquetes.put(tiket.getCodigo(), tiket);
				cliente.agregarTiquete(tiket);
				
			} else {
				
				throw new VueloSobrevendidoException(this);
			}
			
			
		}
		
		return tarifa * cantidad;
		
		
	}


// SE CONSIDERAN IGUALES SI TIENEN LA MISMA RUTA Y FECHA
	
	@Override
	public boolean equals(Object obj) {
		
		
		if(this.getRuta().equals(((Vuelo) obj).getRuta()) && this.getFecha().equals(((Vuelo) obj).getFecha())) {
			return true;
		} else {
			return false;
		}
		
	}
	
//	public int venderTiquetes(Cliente cliente, CalculadoraTarifas calculadora, int cantidad) throws VueloSobrevendidoException {
//		
//	}
}
