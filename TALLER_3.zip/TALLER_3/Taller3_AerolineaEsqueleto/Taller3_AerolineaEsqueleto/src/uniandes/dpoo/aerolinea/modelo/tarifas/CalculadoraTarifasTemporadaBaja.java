package uniandes.dpoo.aerolinea.modelo.tarifas;

import uniandes.dpoo.aerolinea.modelo.Aeropuerto;
import uniandes.dpoo.aerolinea.modelo.Ruta;
import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;
import uniandes.dpoo.aerolinea.modelo.cliente.ClienteCorporativo;

public class CalculadoraTarifasTemporadaBaja extends CalculadoraTarifas {
	
	
	protected int COSTO_POR_KM_CORPORTATIVO = 900;
	protected int COTO_POR_KM_NATURAL = 600;
	protected double DESCUENTO_GRANDES = 0.2;
	protected double DESCUENTO_MEDIANAS = 0.1;
	protected double DESCUENTO_PEQ = 0.02;
	
	
	public CalculadoraTarifasTemporadaBaja() {
		
	}
	
	public int calcularCostoBase(Vuelo vuelo, Cliente cliente) {
		
		int costotal = 0;
		
		Ruta ruta = vuelo.getRuta();
		
//		Aeropuerto origen = ruta.getOrigen();
//		Aeropuerto destino = ruta.getDestino();
		
		int distancia = calcularDistanciaVuelo(ruta);
		
		if(cliente.getTipoCliente().equals("Corporativo")) {
			
			costotal = COSTO_POR_KM_CORPORTATIVO * distancia;
			
		} else if (cliente.getTipoCliente().equals("Natural")) {
			
			costotal = COTO_POR_KM_NATURAL * distancia;
		}
		
		return costotal;
		
	}
	
	public double calcularPorcentajeDescuento(Cliente cliente) {
		
		double descuento = 0;
		
		if(cliente.getTipoCliente().equals("Natural")) {
			descuento = 0;
			
		} else if (cliente.getTipoCliente().equals("Corporativo")) {
			
			ClienteCorporativo clientecor = (ClienteCorporativo) cliente; 
			
			if(clientecor.getTamanoEmpresa() == 1) {
				descuento = DESCUENTO_GRANDES;
				
			} else if (clientecor.getTamanoEmpresa() == 2) {
				descuento = DESCUENTO_MEDIANAS;
				
			} else {
				descuento = DESCUENTO_PEQ;
			}
				
		}
		
		return descuento;
			
	}
	

}
