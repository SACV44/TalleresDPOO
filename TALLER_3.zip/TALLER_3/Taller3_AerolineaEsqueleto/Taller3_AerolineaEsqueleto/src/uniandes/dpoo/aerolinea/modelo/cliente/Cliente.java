package uniandes.dpoo.aerolinea.modelo.cliente;


import java.util.ArrayList;
import java.util.Collection;

import uniandes.dpoo.aerolinea.tiquetes.*;
import uniandes.dpoo.aerolinea.modelo.*;


public abstract class Cliente {
	
	private java.util.List<Tiquete> tiquetesSinUsar;
	private java.util.List<Tiquete> tiquetesUsados;

	
	
	public Cliente() {
		
		this.tiquetesSinUsar = new ArrayList<Tiquete>();
		this.tiquetesUsados = new ArrayList<Tiquete>();
		
	}
	
	
	public void agregarTiquete(Tiquete tiquete) {
		tiquetesSinUsar.add(tiquete);
	}
	
	public int calcularValorTotalTiquetes() {
		
		int tarifatotalsinusar = 0;
		
		
		for(Tiquete t:tiquetesSinUsar) {
			tarifatotalsinusar = tarifatotalsinusar + t.getTarifa();
			
		}
		
		
		
		return tarifatotalsinusar;
		
	}
	
	//FALTA IMPLEMENTAR !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	public void usarTiquetes(Vuelo vuelo) {
	
		Collection<Tiquete> tiquetes = vuelo.getTiquetes().values();
		
		for(Tiquete tiket: tiquetes) {
			
			if (tiket.getCliente() == this) {
				tiquetesSinUsar.remove(tiket);
				
				if (!tiquetesUsados.contains(tiket)) {
				
					tiquetesUsados.add(tiket);
				}
				
			}
			
		}
			
			
		
	}
	
	
	public abstract String getTipoCliente();
		
	public abstract String getIdentificador();
		
		
}
