package uniandes.dpoo.aerolinea.modelo.tarifas;

import uniandes.dpoo.aerolinea.modelo.Aeropuerto;
import uniandes.dpoo.aerolinea.modelo.Ruta;
import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;

public class CalculadoraTarifasTemporadaAlta extends CalculadoraTarifas {
	
	protected final int COSTO_POR_KM = 1000;
	
	public CalculadoraTarifasTemporadaAlta(){
		
	}

	public int calcularCostoBase(Vuelo vuelo, Cliente cliente) {
		
		
		Ruta ruta = vuelo.getRuta();
//		Aeropuerto origen = vuelo.getRuta().getOrigen();
//		Aeropuerto destino = vuelo.getRuta().getDestino();
		
		// int distancia = Aeropuerto.calcularDistancia(origen, destino);
		int distancia = calcularDistanciaVuelo(ruta);
		
		int costotal = COSTO_POR_KM * distancia;
		
		return costotal;
	}
	
	
	public double calcularPorcentajeDescuento(Cliente cliente) {
		
		return 0;
	}
}
