package uniandes.dpoo.aerolinea.persistencia;

import uniandes.dpoo.aerolinea.modelo.Aerolinea;

public class PersistenciaAerolineaJson implements IPersistenciaAerolinea {
	
	
	public void cargarAerolinea(String archivo, Aerolinea aerolinea) {
		// No sirve??
	}
	
	
	public void salvarAerolinea(String archivo, Aerolinea aerolinea) {
		// Tampcoo?
	}
	

}
